#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h>

int main(int argc, char* argv[]) {
    if (argc < 2) {
        return 1;
    }

    int n = argc - 1;
    int arr[n];
    for (int i = 0; i < n; i++) {
        arr[i] = atoi(argv[i + 1]);
    }

    int pipe1[2];
    int pipe2[2];
    int pipe3[2];
    int pipe4[2];

    if (pipe(pipe1) == -1 || pipe(pipe2) == -1 || pipe(pipe3) == -1 || pipe(pipe4) == -1) {
        perror("pipe");
        exit(EXIT_FAILURE);
    }

    __pid_t pid1 = fork();
    if (pid1 == 0) {
        close(pipe1[1]);
        close(pipe2[0]);

        int arr[n];
        read(pipe1[0], arr, sizeof(arr));

        int sum = 0;
        for (int i = 0; i < n; i++) {
            sum += arr[i];
        }

        write(pipe2[1], &sum, sizeof(sum));

        close(pipe1[0]);
        close(pipe2[1]);
        exit(0);
    }

    __pid_t pid2 = fork();
    if (pid2 == 0) {
        close(pipe3[1]);
        close(pipe4[0]);

        int arr[n];
        read(pipe3[0], arr, sizeof(arr));

        int min = arr[0];
        for (int i = 1; i < n; i++) {
            if (arr[i] < min) {
                min = arr[i];
            }
        }

        write(pipe4[1], &min, sizeof(min));

        close(pipe3[0]);
        close(pipe4[1]);
        exit(0);
    }

    close(pipe1[0]);
    close(pipe2[1]);
    close(pipe3[0]);
    close(pipe4[1]);

    write(pipe1[1], arr, sizeof(arr));
    write(pipe3[1], arr, sizeof(arr));

    int sum, min;
    read(pipe2[0], &sum, sizeof(sum));
    read(pipe4[0], &min, sizeof(min));

    printf("Sum: %d\n", sum);
    printf("Min: %d\n", min);

    close(pipe1[1]);
    close(pipe2[0]);
    close(pipe3[1]);
    close(pipe4[0]);

    waitpid(pid1, NULL, 0);
    waitpid(pid2, NULL, 0);

    return 0;
}
